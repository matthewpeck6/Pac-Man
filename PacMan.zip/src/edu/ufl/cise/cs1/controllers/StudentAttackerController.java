package edu.ufl.cise.cs1.controllers;
import game.controllers.AttackerController;
import game.models.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public final class StudentAttackerController implements AttackerController
{
	public void init(Game game) { }

	public void shutdown(Game game) { }

	public int update(Game game,long timeDue) {
		int action;
		action = 0;
		//action = -1;


		//Get enemies and their location
		List<Defender> enemies = game.getDefenders();
		List<Node> enemiesLocation = new ArrayList<>();
		for (int i=0; i < enemies.size(); i++){
			//enemies.get(i).getLocation();
			enemiesLocation.add(enemies.get(i).getLocation());
		}
		Node start = game.getCurMaze().getInitialDefendersPosition();
		Node location = game.getAttacker().getLocation();


		//Get the location of all power pills and normal pills
		List<Node> powerPills = game.getPowerPillList();
		List<Node> pills = game.getPillList();
		boolean parity = game.getPowerPillList().isEmpty();
		Node nearNorPill = game.getAttacker().getTargetNode(pills, true);
		Node closestPill = null;
		if (parity == false){
			closestPill = game.getAttacker().getTargetNode(powerPills, true);
		} else {
			closestPill = game.getAttacker().getTargetNode(pills, true);
		}

		//Variables for getting the closest enemies from the attacker
		int time = 0;
		int lairtime = 0;
		Defender closestEnemies = game.getDefender(0);
		Defender eaten = game.getDefender(0);

		int count = 0;

		//Determines the closest defender
		for (int i=0; i<game.getDefenders().size(); i++){
			if (game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) < game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation())) {
				closestEnemies = game.getDefenders().get(i);
				time = closestEnemies.getVulnerableTime();
				lairtime = closestEnemies.getLairTime();
				count = i;
				//game.getAttacker().getNextDir(game.getDefenders().get(i).getLocation(), false);
			}
		}

		//Determiens the second closest defender
		for (int i=0; i<game.getDefenders().size(); i++){
			if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation())
			&& (game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) < game.getAttacker().getLocation().getPathDistance(eaten.getLocation()))
			)
			{
				 eaten = game.getDefenders().get(i);
				//game.getAttacker().getNextDir(game.getDefenders().get(i).getLocation(), false);
			}
		}

		//Statements that determine the next direction for the attacker
		if ((closestEnemies.getLairTime() != 0 && eaten.getLocation() != start && eaten.getVulnerableTime() != 0)){
			return game.getAttacker().getNextDir(eaten.getLocation(), true);
		}
		if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 9 && !closestEnemies.isVulnerable() ) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) <= 95 && closestEnemies.isVulnerable() )){
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 12) && !closestEnemies.isVulnerable()) {
			return game.getAttacker().getNextDir(closestPill, true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 5) && closestEnemies.isVulnerable() && time >= game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation())) {
			return game.getAttacker().getNextDir(closestPill, true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 5) && closestEnemies.isVulnerable() && time < game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation())) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 3 && (parity == true) )) {
			return game.getAttacker().getNextDir(nearNorPill, false);
		} else {
			return game.getAttacker().getNextDir(nearNorPill, true);
		}

	}
}






		/*
		for (int i = 0; i < enemies.size(); i++){
			if (game.getAttacker().getLocation() == game.getDefender(i).getLocation()) {

			}
		}
		*/

//List<Node> Pills = game.getPillList();
//Node nearNorPill = game.getAttacker().getTargetNode(powerPills, true);

// check if the list is empty or not using function
//boolean parity = game.getPowerPillList().isEmpty();
		/*
		if (ans == true)
			System.out.println("The ArrayList is empty");
		else
			System.out.println("The ArrayList is not empty");

		 */
		/*
		Node closestPill = powerPills.get(0);
		//game.getAttacker().getTargetNode(powerPills, false);
		for (int i = 1; i < powerPills.size(); i++){
			if (powerPills.get(i).getPathDistance(game.getAttacker().getLocation()) < closestPill.getPathDistance(game.getAttacker().getLocation())) {
				closestPill = powerPills.get(i);
			}
		}

		return game.getAttacker().getNextDir(closestPill, true);
		 */
		/*
		for (int i = 1; i < powerPills.size(); i++){

			if  (powerPills.get(i).getPathDistance(game.getAttacker().getLocation()) < closestPill.getPathDistance(game.getAttacker().getLocation())) {
				closestPill = powerPills.get(i);

			}
		}

		 */

//&& closestEnemies.getLocation() !=
//getPathTo closestPill from Current Location
//List<Node> trail = game.getAttacker().getPathTo(powerPills.get(0));

//Get the location of each defender and the attacker, if they are within 10 units, move away from defenders
//List<Defender> enemies = game.getDefenders();
//else if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 9 && !closestEnemies.isVulnerable() ) {
//	return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
//}

		/*
		for (int i=0; i<game.getDefenders().size(); i++){
			if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) &&
			   (game.getAttacker().getLocation().getPathDistance(eaten.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()))
					&& (game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) < game.getAttacker().getLocation().getPathDistance(secfur.getLocation()))
			)
			{
				secfur = game.getDefenders().get(i);
				//game.getAttacker().getNextDir(game.getDefenders().get(i).getLocation(), false);
			}
		}

		for (int i=0; i<game.getDefenders().size(); i++){
			if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) &&
					(game.getAttacker().getLocation().getPathDistance(eaten.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation())) &&
					(game.getAttacker().getLocation().getPathDistance(secfur.getLocation()) < game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()))
			)
			{
				furthest = game.getDefenders().get(i);
				//game.getAttacker().getNextDir(game.getDefenders().get(i).getLocation(), false);
			}
		}

		 */
		/*
		for (int i=0; i<game.getDefenders().size(); i++){
			if (game.getAttacker().getLocation().getPathDistance(game.getDefenders().get(i).getLocation()) == 0){
				for (int j=0; j < enemies.size(); j++){
					if (j == i) {
						continue;
					}
					enemiesLocation.add(enemies.get(i).getLocation());
				}
			}
		}

		 */





		/*
		if (powerPills.size() == 1) {
			return game.getAttacker().getNextDir(closestPill, true);
		}
		else if (powerPills.size() == 1 && game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 10) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		}
		 && closestEnemies.getLocation() != start
		 */
//if close and vun, else if close and not vun, else if not close approach closest power pills, else if no power pills available and enemy close do not approach pills, else approach closest pill
//(game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 30)
//if (game.getAttacker().getDirection() == 1 && game.getAttacker().getLocation().getPathDistance(start) < 5) {
//	return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
//}
		/*
		if (game.getAttacker().getLocation() == closestPill){
			lairtime = 0;
			count = 0;
			game.getDefender(0).getLairTime();
			game.getDefender(1).getLairTime();
			game.getDefender(2).getLairTime();
			game.getDefender(3).getLairTime();
		}
		if (lairtime != 0){
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		}

		 */

//if (closestEnemies.getLocation() == start){
//	return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
//}
//if (game.getDefender(count).getLairTime() != 0){
//	return game.getAttacker().getNextDir(nearNorPill, false);
//}
		/*
		else if (closestEnemies.getLairTime() != 0 && eaten.getLocation() != start && secfur.getLocation() != start && furthest.getLocation() != start) {
			return game.getAttacker().getNextDir(eaten.getLocation(), true);
		}
		else if ((closestEnemies.getLairTime() != 0 && eaten.getLocation() != start && closestEnemies.isVulnerable(){
		    return game.getAttacker().getNextDir(eaten.getLocation(), true);
		}

		 */

//if ((closestEnemies.getLairTime() != 0 && eaten.getLocation() != start)){
//	return game.getAttacker().getNextDir(eaten.getLocation(), true);
//}



//nearNorPill
//closestEnemies.getLocation()
		/*if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 5 && !closestEnemies.isVulnerable() && game.getAttacker().getLocation().getPathDistance(closestPill) <= 50) {
			return game.getAttacker().getNextDir(closestPill, true);
		} else

(game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 5 && !closestEnemies.isVulnerable()) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		}


		  && game.getAttacker().getLocation().getPathDistance(closestPill) > 50
		 */

		/*
		if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 5 && !closestEnemies.isVulnerable() && game.getAttacker().getLocation().getPathDistance(closestPill) <= 50) {

			return game.getAttacker().getNextDir(closestPill, true);
		}

		 */
//&& game.getAttacker().getLocation().getPathDistance(closestPill) > 50
//else if enemy not close and no power pills availabel, appraoch closest normal pill
		/*else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 10 && (parity == true) )) {
			return game.getAttacker().getNextDir(nearNorPill, true);
		}
		*/

//Ingest power pill, want to run into the defender
//boolean parity = game.checkPowerPill();

		/*
		boolean check = closestEnemies.isVulnerable();
		int time = closestEnemies.getVulnerableTime();


		if (check == true && time > 5) {
			Node n = game.getAttacker().getTargetNode(enemiesLocation, true);
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
		} else {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		}

		 */



//return game.getAttacker().getNextDir(closestPill, true);
		/*
		for (int i = 1; i < powerPills.size(); i++){

			if (powerPills.get(i).getPathDistance(game.getAttacker().getLocation()) == closestPill.getPathDistance(game.getAttacker().getLocation())) {
				closestPill = powerPills.get(3);
			}


			else if  (powerPills.get(i).getPathDistance(game.getAttacker().getLocation()) < closestPill.getPathDistance(game.getAttacker().getLocation())) {
				closestPill = powerPills.get(i);

			}
		}

		 */
//ystem.out.println(closestPill);






		/*
		//An example (which should not be in your final submission) of some syntax that randomly chooses a direction for the attacker to move
		List<Integer> possibleDirs = game.getAttacker().getPossibleDirs(true);
		if (possibleDirs.size() != 0)
			action = possibleDirs.get(Game.rng.nextInt(possibleDirs.size()));
		else
			action = -1;

		//An example (which should not be in your final submission) of some syntax to use the visual debugging method, addPathTo, to the top left power pill.
		List<Node> powerPills = game.getPowerPillList();
		if (powerPills.size() != 0) {
			game.getAttacker().addPathTo(game, Color.BLUE, powerPills.get(0));
		}

		 */

//return action;




		/*
		else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 30) && closestEnemies.isVulnerable() && time >= game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation())) {
			return game.getAttacker().getNextDir(closestPill, true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 30) && closestEnemies.isVulnerable() && time < game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation())) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
		}
		 */

		/*
		if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) <= 100 && closestEnemies.isVulnerable() )){
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), true);
		} else if (game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 9 && !closestEnemies.isVulnerable() ) {
			return game.getAttacker().getNextDir(closestEnemies.getLocation(), false);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 30) && !closestEnemies.isVulnerable()) {
			return game.getAttacker().getNextDir(closestPill, true);
		} else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) >= 30) && closestEnemies.isVulnerable()) {
			return game.getAttacker().getNextDir(closestPill, true);
		}else if ((game.getAttacker().getLocation().getPathDistance(closestEnemies.getLocation()) < 5 && (parity == true) )) {
			return game.getAttacker().getNextDir(nearNorPill, false);
		} else {
			return game.getAttacker().getNextDir(nearNorPill, true);
		}
		 */
